<?php
# Digite o nome da máquina onde está localizado o servidor MySQL
$host = "localhost"; //Padrão: localhost

# Digite o nome do usuário do servidor MySQL
$usuario = "User"; // Padrão: root

# Digite a senha do usuário do servidor MySQL
$senha = "Senha"; // Padrão: Minimo 8 Caracters 

# Digite o nome do banco de dados que você deseja utilizar
$nomedobancodedados = "db"; // Não Há Padrão
?>