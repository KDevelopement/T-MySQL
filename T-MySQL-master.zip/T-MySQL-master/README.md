# Para Teste Usamos Servidores Da:
<center>
<a href='http://bit.ly/2fxfnxl'>
<img src='http://image.prntscr.com/image/3f9b1ce0713b4e188d0bba58ca00c517.png' width='400' height='200' alt='Hosted by Umbler'>
</a>
</center>
- Cliquem Na Image, Cadastre-se e ajuda-nós a manter o servidor ativo :)
  *  Ganhe R$25 De Bonus + R$100 Na Instrução Para Manter Sites Online... *

# Demostração
- Tudo Errado:
<img style="-webkit-user-select: none; cursor: zoom-in;" src="http://image.prntscr.com/image/80fb79e4ce094bc3ba81ea11c3e914f5.png" width="1027" height="343"> <br />
- Erro Na Detectação De Bancos De Dados:
<img style="-webkit-user-select: none; cursor: zoom-in;" src="http://image.prntscr.com/image/48f23363b98f4e9ea1017ea6333bd97c.png" width="1027" height="343"> <br />
- Tudo Correto:
<img style="-webkit-user-select: none; cursor: zoom-in;" src="http://image.prntscr.com/image/49f6c8a34fa841f3b31165e26a169928.png" width="1027" height="343"> <br />

<center>
Att <b>CreatWeb</b> - 2016 :)
</center>

# Saiba Mais...

https://github.com/CreatWeb/T-MySQL/wiki
